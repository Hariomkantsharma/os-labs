#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>


int number_upto_which_sum_is_to_be_calculated;
int final_ans = 0;
pthread_mutex_t mutex;
int findsum(int start,int end)
{
    int ans=0;
    for (int i = start; i <= end; i++) {
        ans += i;
    }
    return ans;
}
void* adding(void* thread_id) {
    int thread_number = *(int*)thread_id;
    int start, end;

    // Divide the work between threads
    if (thread_number == 0) {
        start = 1;
        end = number_upto_which_sum_is_to_be_calculated / 2;
    } else {
        start = number_upto_which_sum_is_to_be_calculated / 2 + 1;
        end = number_upto_which_sum_is_to_be_calculated;
    }

    int local_sum = findsum(start,end);
    pthread_mutex_lock(&mutex);
    final_ans += local_sum;
    pthread_mutex_unlock(&mutex);

    pthread_exit(NULL);
}

int main(int argc, char* argv[]) {
    pthread_t threads[2];
    pthread_mutex_init(&mutex, NULL);
    number_upto_which_sum_is_to_be_calculated = atoi(argv[1]);

    if (number_upto_which_sum_is_to_be_calculated <= 0) {
        printf(" Please enter a positive number \n");
        return 1;
    }

    int which_thread[2] = {0, 1};
    // checking if thread creation fails
    for (int i = 0; i < 2; i++) {
        int rc = pthread_create(&threads[i], NULL, adding, (void*)&which_thread[i]);
        if (rc) {
            printf("Error: Unable to create thread %d\n", i);
            return 1;
        }
    }

    for (int i = 0; i < 2; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&mutex);

    printf("Sum of the first %d natural numbers is : %d\n", number_upto_which_sum_is_to_be_calculated, final_ans);

    return 0;
}
