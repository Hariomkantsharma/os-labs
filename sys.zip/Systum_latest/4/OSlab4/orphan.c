#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include<sys/types.h>
int main() {
    pid_t child_pid = fork();
    
    if (child_pid >0) {
            // Parent process
        printf("Parent: I am the parent process and my ID is %d\n", getpid());
        
        printf("Parent: I have created a child process whose id is %d\n", child_pid);
        
	sleep(5); // it is important to put parent to sleep before exiting because otherwise parent will exit before child part is executed and it will become orphan automatically
        // Parent process exits
        
        exit(0);
       
    } else if (child_pid==0) {
 	// Child process
        pid_t papa = getppid();
        printf("Child: I am a child process and my id is %d\n", getpid());
        
        printf("Child: I have been created by my parent process whose id is %d\n", papa);

        // Sleep for 30 seconds
        sleep(30);

        printf("Child: I am a child process and my id is %d\n", getpid());
        
        printf("Child: My current parent id is %d\n", getppid());
        
        exit(0);
    }
    else
    {
    printf("Child cretaion failed");
    exit(0);
    }

    return 0;
}

