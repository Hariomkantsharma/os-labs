#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
// forking the processes
    pid_t child = fork();

    if (child > 0) {
            // Parent process
        printf("Parent says: My process id is  %d\n", getpid());
        printf("Parent says:: My child's process ID is: %d\n", child);

        // Putting on Sleep for 1 minute
        sleep(59);

        // Wait for the child process to exit
        wait(NULL);

        printf("Parent says: Child process has exited.\n");
       
    } else if(child==0) {
 	// Child process
 	pid_t par = getppid();
        printf("Child says: My process ID is: %d\n", getpid());
        printf("Child says: My parent's process ID is: %d\n", par);

        printf("Child: Enter something to exit...\n");
        char sentence[100];  // Wait for user input
	fgets(sentence, sizeof(sentence), stdin);
        printf("Child: Exiting...\n");
        exit(0);
    }
    else
    {
    printf("Child creation failed \n");
    exit(0);
    }

    return 0;
}

