#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<sys/types.h>
#include<unistd.h>

int main(){
    while(1){
        char buf[512];
        int n = read(0, buf, sizeof buf);
        if(n == 0) break;
        if(n < 0){
            printf("read error");
            exit(0);
        }
        if(write(1, buf, n) != n){
            printf("write error");
            exit(0);
        }
        break;
    }
    return 1;
}