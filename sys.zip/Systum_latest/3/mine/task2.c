#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>

int main()
{
pid_t pid;
pid_t getpid(void);
pid_t getppid(void);
pid = fork();
if (pid>0)
{
wait(NULL);
printf("Parent: My process id is : %d \n",getpid());
printf("Parent: My child's process id is: %d \n",pid);
}
else if (pid==0)
{
 printf("Child: My process id is %d \n",getpid());
 printf("Child: the parent process id is %d \n",getppid());
 printf("The child with process id %d has terminated\n",getpid());
}
return 0;
}
