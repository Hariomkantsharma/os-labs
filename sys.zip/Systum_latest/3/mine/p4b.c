#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>
#include <fcntl.h>
int main(int argc, char* argv[])
{
  pid_t pid;
   const char* filename = argv[1];
   int fd = open(filename,O_RDONLY);
    pid = fork();
if (pid>0)
{
//parent
wait(NULL);
printf("Child process is complete\n");
}
else if (pid==0)
{

dup2(fd,STDIN_FILENO);
close(fd);
execl("mycat","mycat",(char*)NULL);
return 1;
}
return 0;
}