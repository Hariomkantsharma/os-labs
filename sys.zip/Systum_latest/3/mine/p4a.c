#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
int main(int argc, char *argv[])
{
    pid_t pid;
    FILE *f = fopen(argv[1], "w");
    pid = fork();
    if (pid > 0)
    {
        // parent
        wait(NULL);
        const char *data = "Hello, World! I am Parent\n";
        fprintf(f, data);
    }
    else if (pid == 0)
    {
        // child
        const char *data = "Hello, World! I am Child\n";
        fprintf(f, data);
    }
}