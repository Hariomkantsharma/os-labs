#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
int main()
{
char buff[512];
int n;
for(;;)
{
    n = read(0,buff,sizeof(buff));
    if(n==0) break;
    if(n<0)
    {
        fprintf(stdout,"read error\n");
        exit(-1);
    }
    if(write(1,buff,n) != n)
    {
        fprintf(stdout,"write error \n");
        exit(-1);
    }
} 
 return 1;
}