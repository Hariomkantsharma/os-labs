#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void philosopherThread(void *pVoid) {
    int *threadIndex = (int *)pVoid;
    printf("This is philosopher %d\n", *threadIndex);
   return;
}

void creatPhilosophers(int nthreads) {
    pthread_t threads[nthreads];
    int threadIndexes[nthreads];

    for (int i = 0; i < nthreads; i++) {
        threadIndexes[i] = i;
        pthread_create(&threads[i], NULL, philosopherThread, &threadIndexes[i]);
    }

    for (int i = 0; i < nthreads; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("%d threads have been completed/joined successfully!\n", nthreads);
}

int main(int argc, char *argv[]) {

    int nthreads = atoi(argv[1]);

    printf("Swapnil Saraswat\n");
    printf("Assignment 7: # of threads = %d\n", nthreads);

    creatPhilosophers(nthreads);

    return 0;
}
