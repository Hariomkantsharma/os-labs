#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define total_philosphers 20

pthread_mutex_t chopsticks[total_philosphers];
pthread_mutex_t globalMutex;
pthread_cond_t condition;
int nextIndex = 0;


void think(int philosopher)
{
    printf("Philosopher %d is thinking.\n", philosopher);
}

void *philosopherThread(void *pVoid)
{
    int philosopherIndex = *(int *)pVoid;
        // thinking
        think(philosopherIndex);
        // waiting for my turn
        pthread_mutex_lock(&globalMutex);

        while (philosopherIndex != nextIndex)
        {
            pthread_cond_wait(&condition, &globalMutex);
            if (philosopherIndex != nextIndex)
            {
                pthread_cond_signal(&condition);
            }
        }

        pthread_mutex_unlock(&globalMutex);

        pthread_mutex_lock(&chopsticks[philosopherIndex]);
        pthread_mutex_lock(&chopsticks[(philosopherIndex + 1) % total_philosphers]);

        printf("philospher %d starts eating \n",philosopherIndex);

        pthread_mutex_unlock(&chopsticks[philosopherIndex]);
        pthread_mutex_unlock(&chopsticks[(philosopherIndex + 1) % total_philosphers]);
        printf("philospher %d stops eating \n",philosopherIndex);
        
        pthread_mutex_lock(&globalMutex);
        nextIndex = (nextIndex + 1) % total_philosphers;
        pthread_cond_signal(&condition);
        pthread_mutex_unlock(&globalMutex);

    pthread_exit(NULL);
}

int main()
{
    pthread_t philosophers[total_philosphers];
    int philosopherIndexes[total_philosphers];

    pthread_mutex_init(&globalMutex, NULL);
    pthread_cond_init(&condition, NULL);

    for (int i = 0; i < total_philosphers; i++)
    {
        pthread_mutex_init(&chopsticks[i], NULL);
        philosopherIndexes[i] = i;
        pthread_create(&philosophers[i], NULL, philosopherThread, &philosopherIndexes[i]);
    }

    for (int i = 0; i < total_philosphers; i++)
    {
        pthread_join(philosophers[i], NULL);
    }

    return 0;
}
