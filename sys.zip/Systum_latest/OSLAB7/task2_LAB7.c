#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

#define total_philosphers 20

pthread_t philosophers[total_philosphers];
pthread_mutex_t chopsticks[total_philosphers];

void thinking(int threadIndex)
{
    printf("Philosopher #%d: starts thinking\n", threadIndex);
    int sleepTime = (rand() % 500) + 1;
    usleep(sleepTime * 1000);
    printf("Philosopher #%d: ends thinking\n", threadIndex);
}

void pickUpChopsticks(int threadIndex)
{
    printf("Philosopher #%d: tries to pick up chopsticks\n", threadIndex);
    pthread_mutex_lock(&chopsticks[threadIndex]);
    pthread_mutex_lock(&chopsticks[(threadIndex + 1) % total_philosphers]);

    printf("Philosopher #%d: successfully picked up chopsticks\n", threadIndex);
}

void eating(int threadIndex)
{
    printf("Philosopher #%d: starts eating\n", threadIndex);
    int sleepTime = (rand() % 500) + 1;
    usleep(sleepTime * 1000);
    printf("Philosopher #%d: ends eating\n", threadIndex);
}

void putDownChopsticks(int threadIndex)
{
    printf("Philosopher #%d: puts down chopsticks\n", threadIndex);
    pthread_mutex_unlock(&chopsticks[threadIndex]);
    pthread_mutex_unlock(&chopsticks[(threadIndex + 1) % total_philosphers]);
}

void *philosopherThread(void *arg)
{
    int threadIndex = *(int *)arg;
    while (1)
    {
        thinking(threadIndex);
        pickUpChopsticks(threadIndex);
        eating(threadIndex);
        putDownChopsticks(threadIndex);
        break;
    }
    return NULL;
}

int main()
{

    for (int i = 0; i < total_philosphers; i++)
    {
        pthread_mutex_init(&chopsticks[i], NULL);
    }

    int threadIndices[total_philosphers];
    for (int i = 0; i < total_philosphers; i++)
    {
        threadIndices[i] = i;
        pthread_create(&philosophers[i], NULL, philosopherThread, &threadIndices[i]);
    }

    for (int i = 0; i < total_philosphers; i++)
    {
        pthread_join(philosophers[i], NULL);
    }

    return 0;
}
