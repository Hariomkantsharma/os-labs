#include <stdio.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

/*
    shmget() allocates as much physical memory as you request for the segment.

    shmat() programs the MMU and sets things up in the kernel so that some address range in your process maps to the segment.

    shmdt() does the reverse operation and removes the mapping.

    shmctl() with IPC_RMID deallocates the physical memory of the segment (marks it as free).
*/
int main() {
    int shmid;
    key_t key = ftok("shmfile", 65);

    shmid = shmget(key, sizeof(int), IPC_CREAT | 0666);
    int *shm = (int*)shmat(shmid, NULL, 0);
    *shm = 0;

    // A
    if (fork() == 0) {
        for (int i = 0; i < 100000; i++) {
            usleep(1);
            (*shm)++;  
        }
        _exit(0);
    }
 // B
    if (fork() == 0) {
        for (int i = 0; i < 100000; i++) {
            usleep(1);
            (*shm)--;  
        }
        _exit(0);
    }

    wait(NULL);
    wait(NULL);


    printf("Final value of X: %d\n", *shm);

    shmdt(shm);
    shmctl(shmid, IPC_RMID, NULL);

    return 0;
}
