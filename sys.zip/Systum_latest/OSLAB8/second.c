#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <unistd.h>
union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

void processA(int *X, int semid) {
    for (int i = 0; i < 100000; i++) {
        struct sembuf sem_lock = {0, -1, SEM_UNDO};
        semop(semid, &sem_lock, 1);

        (*X)++; // Increment X by 1

        struct sembuf sem_unlock = {0, 1, SEM_UNDO};
        semop(semid, &sem_unlock, 1);
    }
}

void processB(int *X, int semid) {
    for (int i = 0; i < 100000; i++) {
        struct sembuf sem_lock = {0, -1, SEM_UNDO};
        semop(semid, &sem_lock, 1);

        (*X)--; // Decrement X by 1

        struct sembuf sem_unlock = {0, 1, SEM_UNDO};
        semop(semid, &sem_unlock, 1);
    }
}

int main() {
    int shmid;
    int *X;

   
    key_t key = ftok("shared_memory_key", 65);
    shmid = shmget(key, sizeof(int), 0666 | IPC_CREAT);


    int semid;
    semid = semget(key, 1, 0666 | IPC_CREAT);


    union semun semarg;
    semarg.val = 1;
    semctl(semid, 0, SETVAL, semarg);


    X = (int *)shmat(shmid, NULL, 0);


    pid_t pidA, pidB;
    pidA = fork();

    if (pidA == 0) {
        // A
        processA(X, semid);
    } else {
        //parent process
        pidB = fork();

        if (pidB == 0) {
            // B
            processB(X, semid);
        } else {
            // This is still the parent process
            wait(NULL); 
            wait(NULL); 

            
            printf("Final value of X: %d\n", *X);

       
            shmdt(X);
            shmctl(shmid, IPC_RMID, NULL);
        }
    }

    return 0;
}
