#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cout<<"Enter The Number of Processes"<<endl;
    cin>>n;
    cout<<"Enter The arrival time for each process"<<endl;
    vector<int> arrival(n);
    for(int i=0;i<n;i++){
        cin>>arrival[i];
    }
    cout<<"Enter The Burst time for each process"<<endl;
    vector<int> burst(n);
    for(int i=0;i<n;i++){
        cin>>burst[i];
    }
    vector<pair<int,pair<int,int>>> proc;
    for(int i=0;i<n;i++){
        proc.push_back({arrival[i],{i,burst[i]}});
    }
    sort(proc.begin(),proc.end());
    int time = 0;
    vector<int> wt(n);
    vector<int> tat(n);
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;
    int ind = 0;
    int prev = -1;
    while(ind < n || !pq.empty()){
        if(ind < n && proc[ind].first <= time){
            pq.push({proc[ind].second.second,proc[ind].second.first});
            ind++;
        }
        int pid = pq.top().second;
        int exec = pq.top().first;
        pq.pop();
        if(prev == -1) prev = pid;
        if(pid != prev){
            cout<<"context switch at time "<<time;
            cout<<" entering process: "<<pid<<" leaving process: "<<prev<<endl;
            prev = pid;
        }
        exec--;
        time++;
        if(exec == 0){
            tat[pid] = (time - arrival[pid]);
            wt[pid] = tat[pid] - burst[pid];
        }
        else
        pq.push({exec,pid});
    }
    double avg_wt = 0, avg_tat = 0;
    for(int i=0;i<n;i++){
        avg_wt += wt[i];
        avg_tat += tat[i];
    }
    avg_wt /= n;
    avg_tat /= n;
    cout<<"average waiting time: "<<avg_wt<<endl;
    cout<<"average tat time: "<<avg_tat<<endl;
    return 0;
}