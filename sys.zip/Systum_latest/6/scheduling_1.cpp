#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cout<<"Enter The Number of Processes"<<endl;
    cin>>n;
    cout<<"Enter The arrival time for each process"<<endl;
    vector<int> arrival(n);
    for(int i=0;i<n;i++){
        cin>>arrival[i];
    }
    cout<<"Enter The Burst time for each process"<<endl;
    vector<int> burst(n);
    for(int i=0;i<n;i++){
        cin>>burst[i];
    }
    vector<pair<int,pair<int,int>>> proc;
    for(int i=0;i<n;i++){
        proc.push_back({arrival[i],{i,burst[i]}});
    }
    sort(proc.begin(),proc.end());
    int time = 0;
    vector<int> wt(n);
    vector<int> tat(n);
    for(int i=0;i<n;i++){
        int pid = proc[i].second.first;
        wt[i] += (time - proc[i].first);
        tat[i] = (time - proc[i].first) + proc[i].second.second;
        time += proc[i].second.second;
        
    }
    double avg_wt = 0, avg_tat = 0;
    for(int i=0;i<n;i++){
        avg_wt += wt[i];
        avg_tat += tat[i];
        cout<<tat[i]<<" ";
    }
    avg_wt /= n;
    avg_tat /= n;
    cout<<"average waiting time: "<<avg_wt<<endl;
    cout<<"average tat time: "<<avg_tat<<endl;
    return 0;
}