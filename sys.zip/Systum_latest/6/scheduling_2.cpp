#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cout<<"Enter The Number of Processes"<<endl;
    cin>>n;
    cout<<"Enter The arrival time for each process"<<endl;
    vector<int> arrival(n);
    for(int i=0;i<n;i++){
        cin>>arrival[i];
    }
    cout<<"Enter The Burst time for each process"<<endl;
    vector<int> burst(n);
    for(int i=0;i<n;i++){
        cin>>burst[i];
    }
    vector<pair<int,pair<int,int>>> proc;
    for(int i=0;i<n;i++){
        proc.push_back({arrival[i],{i,burst[i]}});
    }
    sort(proc.begin(),proc.end());
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;
    int ind = 0;
    int time = 0;
    vector<int> wt(n);
    vector<int> tat(n);
    while(ind < n || !pq.empty()){
        while(ind < n && proc[ind].first <= time){
            pq.push({proc[ind].second.second,proc[ind].second.first});
            ind++;
        }
        if(pq.empty()){
            time++;
            continue;
        }
        int pid = pq.top().second;
        pq.pop();
        wt[pid] = (time - arrival[pid]);
        tat[pid] = wt[pid] + burst[pid];
        time += burst[pid];
    }
    double avg_wt = 0, avg_tat = 0;
    for(int i=0;i<n;i++){
        avg_wt += wt[i];
        avg_tat += tat[i];
    }
    avg_wt /= n;
    avg_tat /= n;
    cout<<"average waiting time: "<<avg_wt<<endl;
    cout<<"average tat time: "<<avg_tat<<endl;
    return 0;
}