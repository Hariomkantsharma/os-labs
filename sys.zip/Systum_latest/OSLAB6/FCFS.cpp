#include<bits/stdc++.h>
using namespace std;
int main()
{
    using pp = pair<int,int>;  
    pp a = {0,5};
    pp b = {1,3};
    pp c = {2,8};
    pp d = {3,6};
    vector<int>wt;
    vector<int>tat;
    int time = 0;
    // tat = completion - arrival
    // wt = tat - bt
    // task -> find completion time using FCFS algorithm
    multiset<pp>st;
    st.insert(a);
    st.insert(b);
    st.insert(c);
    st.insert(d);
    int n = 4;
    for(int i=0;i<n;i++)
    {
        pp temp = *st.begin();
        int bt = temp.second;
        int arrival = temp.first;
        time += bt;
        int comp = time;
        int tat_time = comp-arrival;
        int wt_time = tat_time-bt;
        wt.push_back(wt_time);
        tat.push_back(tat_time); 
        st.erase(st.find(temp)); 
    }
    double avg_tat=0,avg_wait=0;
    for(int x: tat) avg_tat += x;
    avg_tat /= n;
    for(int x:wt) avg_wait += x;
    avg_wait/=n;
    cout<<"tat times: ";
    for(int x: tat) cout<<x<<" ";
    cout<<endl;
    cout<<"wt times: ";
    for(int x: wt) cout<<x<<" ";
    cout<<endl;
    cout<<avg_tat<<" "<<avg_wait<<endl;
    return 0;
}
