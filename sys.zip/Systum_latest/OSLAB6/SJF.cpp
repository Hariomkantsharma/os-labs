#include<bits/stdc++.h>
using namespace std;
int main()
{
    // find completion time using SJF
    using pp = pair<int,int>;  
    pp a = {2,6};
    pp b = {5,2};
    pp c = {1,8};
    pp d = {0,3};
    pp e = {4,4};
    vector<int>wt;
    vector<int>tat;
    int time = 0;
    multiset<pp>st;
    st.insert(a);
    st.insert(b);
    st.insert(c);
    st.insert(d);
    st.insert(e);
    int n = 5;
    pp next = *st.begin();

    for(int i=0;i<n;i++)
    {
        int arrival= next.first;
        int bt = next.second;
        time+=bt;
        int comp = time;
        int tat_time = comp-arrival;
        int wt_time = tat_time-bt;
        wt.push_back(wt_time);
        tat.push_back(tat_time); 
        st.erase(st.find(next));
        multiset<pp>temp;

        for(auto it = st.begin();it!=st.end();it++)
        {
            pp temp2 = *it;
            if(temp2.first<time) temp.insert({temp2.second,temp2.first});
        }
        pp hi = *temp.begin();
        next = {hi.second,hi.first};
    }
     double avg_tat=0,avg_wait=0;
    for(int x: tat) avg_tat += x;
    avg_tat /= n;
    for(int x:wt) avg_wait += x;
    avg_wait/=n;
    cout<<"tat times: ";
    for(int x: tat) cout<<x<<" ";
    cout<<endl;
    cout<<"wt times: ";
    for(int x: wt) cout<<x<<" ";
    cout<<endl;
    cout<<avg_tat<<" "<<avg_wait<<endl;
    return 0;
}