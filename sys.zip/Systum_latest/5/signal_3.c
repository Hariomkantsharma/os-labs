#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<sys/types.h>
#include<signal.h>

void signal_handler(int signum){
	pid_t pid;
	int status;
	pid = wait(&status);
	printf("Process with pid %d is exitting with status %d",pid,WEXITSTATUS(status));
}

int main(){
	signal(SIGCHLD,signal_handler);

	pid_t pid = fork();
	if(pid < 0){
		printf("Child process could not be created.\n");
		exit(-1);
	}
	else if(pid == 0){
		pid_t pid2 = fork();
		if(pid2 < 0){
			printf("GrandChild process could not be created.\n");
		    exit(-1);
		}
		else if(pid2 == 0){
			printf("GrandChild: My pid is %d\n",getpid());
			sleep(3);
			printf("GrandChild exitting!\n");
			exit(2);
		}
		else{
			printf("Child: My PID is %d\n",getpid());
			sleep(30);
			printf("Child exitting!\n");
			exit(1);
		}
	}
	else{
		printf("Parent: My pid is %d\n",getpid());
		sleep(60);
		printf("Parent exitting!.\n");
	}
}