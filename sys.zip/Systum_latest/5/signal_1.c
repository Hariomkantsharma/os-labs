#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<signal.h>

void signal_handler(int signum){
	printf("Received signal - %d\n",signum);
	printf("Do you really wish to exit?(y/n)\n");
	char ch;
	scanf("%c",&ch);
	if(ch == 'y'){
		exit(0);
	}
}

int main(){
	//use ctrl c to generate SIGINT signal
	signal(SIGINT,signal_handler);
	
	//use kill -TERM <pid> to generate SIGTERM signal
	signal(SIGTERM,signal_handler);

	pid_t pid = getpid();
	printf("%d\n",pid);
	while(1);
	return 0;
}