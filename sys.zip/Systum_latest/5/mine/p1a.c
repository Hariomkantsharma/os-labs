#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
int terminationConfirmed=1;
void signal_handler(int signum) {
	printf("\nReceived SIGINT (Ctrl+C)\n");
	printf("Do you want to exit the process? Input 0 or 1 ");
	int yesorno;
	scanf(" %d", &yesorno);
	if (yesorno == 1) {
    	terminationConfirmed = 1;
        printf("Process Exited \n");
    	exit(0);
	}
}

int main()
{
    signal(SIGINT,signal_handler);
    printf("Processid of this process is %d \n",getpid());
    while (terminationConfirmed)
    {
        sleep(1);
    };
}
