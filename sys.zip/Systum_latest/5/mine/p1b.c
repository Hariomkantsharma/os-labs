 #include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
void signal_handler(int signal)
{
 printf("Caught signal %d \n",signal);
 if(signal == SIGCHLD)
 {
    printf("SIGCHLD caught for process %d \n",getpid());
    exit(0);
 }
}
int main(int argc,char* argv[])
{
    int n = argv[1][0] - '0';
    printf("%d \n",n);
    signal(SIGCHLD,signal_handler);

    while(n--)
    {
        if(!fork())
        {
            printf("child created \n");
            sleep(rand()%10);
            printf("Processid of this process is %d \n",getpid());
            kill(getpid(),SIGCHLD);
        }
    }
	getchar();
}