#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <time.h>


void sigchldHandler(int signum) // signal handling
{
	int status;
	pid_t child_pid;

	while ((child_pid = waitpid(-1, &status, WNOHANG)) > 0)
	{
    	if (WIFEXITED(status))
    	{
        	printf("process %d exited with status %d\n", child_pid, WEXITSTATUS(status));
    	}
	}
}

int main()
{
	signal(SIGCHLD, sigchldHandler);

	srand(time(NULL)); // seeding

	pid_t child_pid = fork();

	if (child_pid == 0)
	{
    	printf("Child process is running\n");

    	pid_t grandchild_pid = fork();

    	if (grandchild_pid == 0)
    	{
        	int sleep_duration = 7; //sleep for gc
        	sleep(sleep_duration);
        	printf("Grandchild process is exiting after sleeping for %d seconds with pid  = %d \n", sleep_duration,getpid());
        	exit(0);
    	}
        
    	int sleep_duration =10; // sleep for child
    	sleep(sleep_duration);
    	printf("Child process is exiting after sleeping for %d seconds with pid  = %d \n", sleep_duration,getpid());
    	exit(0);
	}

	printf("Parent process is waiting for child process to exit...\n");
	while (1)
	{
    	pause(); // Wait for a signal (SIGCHLD) to be received
    	break;
	}

	return 0;
}






