#include <stdio.h>
#include <stdlib.h>
// Define the data structure for a key-value pair
typedef struct KeyValue {
    int key;
    int value;
} KeyValue;

// Define the MRU Cache structure
typedef struct MRUCache {
    int capacity;
    KeyValue* cache;
    int* mru_order;
    int size;
} MRUCache;

// Initialize the MRU Cache
MRUCache* createMRUCache(int capacity) {
    MRUCache* cache = (MRUCache*)malloc(sizeof(MRUCache));
    cache->capacity = capacity;
    cache->cache = (KeyValue*)malloc(capacity * sizeof(KeyValue));
    cache->mru_order = (int*)malloc(capacity * sizeof(int));
    cache->size = 0;

    // Initialize MRU order to -1 (not used)
    for (int i = 0; i < capacity; i++) {
        cache->mru_order[i] = -1;
    }

    return cache;
}

// Function to get a value from the MRU Cache
int get(MRUCache* cache, int key) {
    for (int i = 0; i < cache->size; i++) {
        if (cache->cache[i].key == key) {
            // Move the accessed key to the front of MRU order
            int accessed = cache->mru_order[i];
            for (int j = i; j > 0; j--) {
                cache->mru_order[j] = cache->mru_order[j - 1];
            }
            cache->mru_order[0] = accessed;

            return cache->cache[i].value;
        }
    }
    return -1;
}

// Function to set a key-value pair in the MRU Cache
void set(MRUCache* cache, int key, int value) {
    if (cache->size == cache->capacity) {
        // Remove the most recently used key
        int lru_key = cache->mru_order[0];
        for (int i = 0; i < cache->size; i++) {
            if (cache->cache[i].key == lru_key) {
                for (int j = i; j < cache->size - 1; j++) {
                    cache->cache[j] = cache->cache[j + 1];
                    cache->mru_order[j] = cache->mru_order[j + 1];
                }
                cache->size--;
                break;
            }
        }
    }

    // Add the new key-value pair and update MRU order
    for (int i = cache->size; i > 0; i--) {
        cache->cache[i] = cache->cache[i - 1];
        cache->mru_order[i] = cache->mru_order[i - 1];
    }
    cache->cache[0].key = key;
    cache->cache[0].value = value;
    cache->mru_order[0] = key;
    cache->size++;
}

int main() {
    int t;
    scanf("%d", &t);

    while (t--) {
        int cap, Q;
        printf("enter cap \n");
        scanf("%d", &cap);
     printf("enter number of queries \n");
        scanf("%d", &Q);
        MRUCache* cache = createMRUCache(cap);

        int get_results[Q];
        int query_type, key, value;
        int index = 0;
 printf("enter queries \n");
        for (int i = 0; i < Q; i++) {
            scanf(" %c", &query_type);
            if (query_type == 'S') {
                scanf("%d %d", &key, &value);
                set(cache, key, value);
            } else if (query_type == 'G') {
                scanf("%d", &key);
                get_results[index] = get(cache, key);
                index++;
            }
        }

        // Print the results for 'GET' queries
        for (int i = 0; i < index; i++) {
            printf("%d ", get_results[i]);
        }
        printf("\n");

        free(cache->cache);
        free(cache->mru_order);
        free(cache);
    }

    return 0;
}
