# include <bits/stdc++.h>
using namespace std;


void solve(){
   map<int,int> ds;
   int mru = -1;
   int siz; cin >> siz;
   int q; cin >> q;
   while(q--){
       if(ds.size()==siz){
           ds.erase(mru);
       }
       char t; cin >> t;
       int x; cin >> x;
       mru = x;
       if(t=='S'){
           int y; cin >> y;
           ds[x]=y;
       }else{
           if(ds[x]==0){
               cout << -1 << endl;
           }else cout << ds[x] << endl;
       }
   }
}


int main(){
   int t; cin >> t;
   while(t--){
       solve();
   }   
   return 0;
}
