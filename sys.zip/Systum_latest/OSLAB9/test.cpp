
#include <bits/stdc++.h>
using namespace std;

vector<vector<int>> ans;
vector<vector<int>> v;
void recur(vector<int> &subans, int n, vector<int> &flag, int a, int b, int c)
{

    if (n == flag.size())
    {
        ans.push_back(subans);
        return;
    }
    for (int i = 0; i < flag.size(); i++)
    {
        if (v[i][0] + a >= v[i][3] && v[i][1] + b >= v[i][4] && v[i][2] + c >= v[i][5] && flag[i] == 0)
        {
            flag[i] = 1;
            subans.push_back(i);
            recur(subans, n + 1, flag, v[i][0] + a, v[i][1] + b, v[i][2] + c);
            subans.pop_back();
            flag[i] = 0;
        }
    }
}
int main()
{
    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
    {
        ans.clear();
        v.clear();
        int n;
        cin >> n;
        int a, b, c;
        cin >> a >> b >> c;

        for (int i = 0; i < n; i++)
        {
            int x, y, z, alpha, beta, gama;
            cin >> x >> y >> z >> alpha >> beta >> gama;
            v.push_back({x, y, z, alpha, beta, gama});
        }

        vector<int> flag;
        for (int i = 0; i < n; i++)
            flag.push_back(0);

        vector<int> f;
        recur(f, 0, flag, a, b, c);

        if (ans.size() == 0)
            cout << "NO SOLUTION" << endl;
        else
        {
            for (int i = 0; i < ans.size(); i++)
            {
                for (int j = 0; j < ans[i].size(); j++)
                {
                    cout << ans[i][j] << " ";
                }
                cout << ";";
            }
        }
    }
}