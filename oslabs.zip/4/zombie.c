#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Fork failed\n");
        return 1;
    }

    if (pid == 0) {
        // Child process printing at the beginning
        printf("Child: My process ID is: %d\n", getpid());
        printf("Child: The parent process ID is: %d\n", getppid());

        printf("Child: Press any key and Enter to exit...\n");
        getchar();  // Getting the input from the user

        printf("Child: Exiting...\n");
        exit(0);
    } else {
        // Parent process printing the process IDs
        printf("Parent: My process ID is: %d\n", getpid());
        printf("Parent: The child process ID is: %d\n", pid);

        sleep(60);  // Sleep for 1 minute

        // Wait for the child process to exit
        wait(NULL);

        printf("Parent: Child process has exited\n");
    }

    return 0;
}
