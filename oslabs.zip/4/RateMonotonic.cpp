#include <stdio.h>
#include <stdlib.h>

// Structure to represent a task
typedef struct {
  int period; // The period of the task
  int execution_time; // The execution time of the task
  int priority; // The priority of the task
} task_t;

// Function to compare two tasks based on their priorities
int compare_tasks(const void *a, const void *b) {
  task_t *task_a = (task_t *)a;
  task_t *task_b = (task_t *)b;
  return task_a->priority - task_b->priority;
}

// Function to schedule a set of tasks using the rate monotonic algorithm
void rate_monotonic_scheduling(task_t *tasks, int num_tasks) {
  // Sort the tasks in descending order of priority
  qsort(tasks, num_tasks, sizeof(task_t), compare_tasks);

  // Calculate the utilization of the system
  float utilization = 0.0;
  for (int i = 0; i < num_tasks; i++) {
    utilization += (float)tasks[i].execution_time / (float)tasks[i].period;
  }

  // Check if the system is overloaded
  if (utilization > 1.0) {
    printf("The system is overloaded!\n");
    return;
  }

  // Schedule the tasks
  int current_time = 0;
  while (1) {
    // Find the highest priority task that is ready to run
    int highest_priority_task = 0;
    for (int i = 0; i < num_tasks; i++) {
      if (current_time % tasks[i].period == 0) {
        highest_priority_task = i;
        break;
      }
    }

    // Run the highest priority task
    printf("Running task %d\n", highest_priority_task);
    current_time += tasks[highest_priority_task].execution_time;
  }
}

int main() {
  // Create a set of tasks
  task_t tasks[3];
  tasks[0].period = 10;
  tasks[0].execution_time = 5;
  tasks[0].priority = 0;

  tasks[1].period = 20;
  tasks[1].execution_time = 10;
  tasks[1].priority = 1;

  tasks[2].period = 30;
  tasks[2].execution_time = 15;
  tasks[2].priority = 2;

  // Schedule the tasks
  rate_monotonic_scheduling(tasks, 3);

  return 0;
}
