#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Fork failed\n");
        return 1;
    }

    if (pid == 0) {
        // Child process prints at the start of the process
        printf("Child: I am a child process and my id is %d\n", getpid());
        printf("Child: I have been created by my parent process whose id is %d\n", getppid());

        sleep(30);

        // Child process prints at the end of the process
        printf("\nChild: I am a child process and my id is %d\n", getpid());
        printf("Child: My current parent id is %d\n", getppid());
        exit(0);
    } else {
        // Parent process prints at the end of the process
        printf("Parent: I am the parent process and my ID is %d\n", getpid());
        printf("Parent: I have created a child process whose id is %d\n", pid);
        
        // Parent process exits immediately
        exit(0);
    }

    return 0;
}
