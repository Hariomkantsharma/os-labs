#include <pthread.h>
#include <stdio.h>

// Structure to store the arguments for the two threads
typedef struct {
  int n;
  int *numbers;
  int *result;
} thread_args_t;

// Function to add n numbers
void *add_numbers(void *args) {
  thread_args_t *thread_args = (thread_args_t *)args;
  int sum = 0;
  for (int i = 0; i < thread_args->n; i++) {
    sum += thread_args->numbers[i];
  }
  thread_args->result[0] = sum;
  return NULL;
}

// Function to multiply n numbers
void *multiply_numbers(void *args) {
  thread_args_t *thread_args = (thread_args_t *)args;
  int product = 1;
  for (int i = 0; i < thread_args->n; i++) {
    product *= thread_args->numbers[i];
  }
  thread_args->result[1] = product;
  return NULL;
}

int main() {
  // Get the number of numbers to add and multiply
  int n;
  printf("Enter the number of numbers to add and multiply: ");
  scanf("%d", &n);

  // Allocate memory for the numbers and the results
  int *numbers = (int *)malloc(n * sizeof(int));
  int *results = (int *)malloc(2 * sizeof(int));

  // Get the numbers from the user
  for (int i = 0; i < n; i++) {
    printf("Enter number %d: ", i + 1);
    scanf("%d", &numbers[i]);
  }

  // Create the two threads
  pthread_t thread1, thread2;
  thread_args_t thread_args1, thread_args2;

  // Initialize the arguments for the two threads
  thread_args1.n = n;
  thread_args1.numbers = numbers;
  thread_args1.result = results;

  thread_args2.n = n;
  thread_args2.numbers = numbers;
  thread_args2.result = results;

  // Create the two threads
  pthread_create(&thread1, NULL, add_numbers, (void *)&thread_args1);
  pthread_create(&thread2, NULL, multiply_numbers, (void *)&thread_args2);

  // Join the two threads
  pthread_join(thread1, NULL);
  pthread_join(thread2, NULL);

  // Print the results
  printf("The sum of the numbers is %d\n", results[0]);
  printf("The product of the numbers is %d\n", results[1]);

  // Free the allocated memory
  free(numbers);
  free(results);

  return 0;
}
