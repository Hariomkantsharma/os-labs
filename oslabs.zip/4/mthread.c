#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int number;
int result = 0;
pthread_mutex_t mutex;

// Function to add the number and update the global variable
// The function will have a threadId as an argument and based on its value it will calculate the value of the sum and update the global variable result
// The function will also use a mutex to ensure that the global variable is updated correctly
void* add(void* arg) {
    int threadId = *((int*)arg);
    int start, end;
    start = (threadId == 0) ? 1 : number / 2 + 1;
    end = (threadId == 0) ? number / 2 : number;

    int sum = 0;
    for (int i = start; i <= end; ++i) {
        sum += i;
    }

    // Taking the lock and then updating the result
    pthread_mutex_lock(&mutex);
    result += sum;
    pthread_mutex_unlock(&mutex);
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Please pass an integer as an input\n");
        return 1;
    }

    // Converting string to integer
    number = atoi(argv[1]);

    // Checking the number as negative
    if (number <= 0) {
        printf("Number must be a positive integer.\n");
        return 1;
    }

    // Creating two threads
    pthread_t threads[2];
    int threadIds[2] = {0, 1};

    pthread_mutex_init(&mutex, NULL);

    // Creating two threads and giving the start_routine as add function
    pthread_create(&threads[0], NULL, add, &threadIds[0]);
    pthread_create(&threads[1], NULL, add, &threadIds[1]);

    // Waiting for the threads to finish and then join them
    pthread_join(threads[0], NULL);
    pthread_join(threads[1], NULL);

    // Destroying the mutex
    pthread_mutex_destroy(&mutex);

    printf("Sum of first %d natural numbers: %d\n", number, result);

    return 0;
}
