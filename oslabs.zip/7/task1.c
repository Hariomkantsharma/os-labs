#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *philosopherThread(void *pVoid) {
    int philosopherIndex = *((int *)pVoid);
    printf("This is philosopher %d\n", philosopherIndex);
    return NULL;
}

void createPhilosophers(int nthreads) {
    pthread_t threads[nthreads];
    int threadArgs[nthreads];

    for (int i = 0; i < nthreads; i++) {
        threadArgs[i] = i;
        pthread_create(&threads[i], NULL, philosopherThread, &threadArgs[i]);
    }

    for (int i = 0; i < nthreads; i++) {
        pthread_join(threads[i], NULL);
    }


    printf("%d threads have been completed/joined successfully!\n", nthreads);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <number of threads>\n", argv[0]);
        return 1;
    }

    int nthreads = atoi(argv[1]);

    printf("Anurag Deo's Assignment 7: # of threads = %d\n", nthreads);
    createPhilosophers(nthreads);

    return 0;
}
