#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

#define NUM_PHILOSOPHERS 5
#define NUM_CYCLES 1

pthread_mutex_t chopsticks[NUM_PHILOSOPHERS];

void thinking(int philosopherIndex) {
    printf("Philosopher #%d: starts thinking\n", philosopherIndex);
    int sleepTime = (rand() % 500) + 1;
    usleep(sleepTime * 1000);  // Sleep in milliseconds
    printf("Philosopher #%d: ends thinking\n", philosopherIndex);
}

void pickUpChopsticks(int philosopherIndex) {
    int leftChopstick = philosopherIndex;
    int rightChopstick = (philosopherIndex + 1) % NUM_PHILOSOPHERS;

    // Lock the left chopstick
    pthread_mutex_lock(&chopsticks[leftChopstick]);
    printf("Philosopher #%d: picks up left chopstick %d\n", philosopherIndex, leftChopstick);

    // Lock the right chopstick
    pthread_mutex_lock(&chopsticks[rightChopstick]);
    printf("Philosopher #%d: picks up right chopstick %d\n", philosopherIndex, rightChopstick);
}

void eating(int philosopherIndex) {
    printf("Philosopher #%d: starts eating\n", philosopherIndex);
    int sleepTime = (rand() % 500) + 1;
    usleep(sleepTime * 1000);  // Sleep in milliseconds
    printf("Philosopher #%d: ends eating\n", philosopherIndex);
}

void putDownChopsticks(int philosopherIndex) {
    int leftChopstick = philosopherIndex;
    int rightChopstick = (philosopherIndex + 1) % NUM_PHILOSOPHERS;

    // Unlock the left chopstick
    pthread_mutex_unlock(&chopsticks[leftChopstick]);
    printf("Philosopher #%d: puts down left chopstick %d\n", philosopherIndex, leftChopstick);

    // Unlock the right chopstick
    pthread_mutex_unlock(&chopsticks[rightChopstick]);
    printf("Philosopher #%d: puts down right chopstick %d\n", philosopherIndex, rightChopstick);
}

void *philosopherThread(void *pVoid) {
    int philosopherIndex = *((int *)pVoid);

    for (int cycle = 0; cycle < NUM_CYCLES; cycle++) {
        thinking(philosopherIndex);
        pickUpChopsticks(philosopherIndex);
        eating(philosopherIndex);
        putDownChopsticks(philosopherIndex);
        // printf("Completed %d\n",cycle);
    }

    return NULL;
}

int main() {
    srand(time(NULL));

    pthread_t threads[NUM_PHILOSOPHERS];
    int threadArgs[NUM_PHILOSOPHERS];

    // Initializing the mutex
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        pthread_mutex_init(&chopsticks[i], NULL);
    }

    // Creating the threads
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        threadArgs[i] = i;
        pthread_create(&threads[i], NULL, philosopherThread, &threadArgs[i]);
    }

    // Joining the threads
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        pthread_join(threads[i], NULL);
    }

    // Destroying the threads
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        pthread_mutex_destroy(&chopsticks[i]);
    }

    return 0;
}
