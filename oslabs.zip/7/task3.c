#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

#define NUM_PHILOSOPHERS 5
#define NUM_CYCLES 1

pthread_mutex_t globalMutex;
pthread_cond_t nextPhilosopher;
int nextIndex = 0;

void thinking(int philosopherIndex) {
    printf("Philosopher #%d: starts thinking\n", philosopherIndex);
    int sleepTime = (rand() % 500) + 1;
    usleep(sleepTime * 1000);
    printf("Philosopher #%d: ends thinking\n", philosopherIndex);
}

void pickUpChopsticks(int philosopherIndex) {
    pthread_mutex_lock(&globalMutex);

    while (nextIndex != philosopherIndex) {
        pthread_cond_wait(&nextPhilosopher, &globalMutex);
    }

    int leftChopstick = philosopherIndex;
    int rightChopstick = (philosopherIndex + 1) % NUM_PHILOSOPHERS;

    printf("Philosopher #%d: picks up left chopstick %d\n", philosopherIndex, leftChopstick);
    printf("Philosopher #%d: picks up right chopstick %d\n", philosopherIndex, rightChopstick);

    nextIndex = (nextIndex + 1) % NUM_PHILOSOPHERS;
    pthread_cond_broadcast(&nextPhilosopher);

    pthread_mutex_unlock(&globalMutex);
}

void eating(int philosopherIndex) {
    printf("Philosopher #%d: starts eating\n", philosopherIndex);
    int sleepTime = (rand() % 500) + 1;
    usleep(sleepTime * 1000);
    printf("Philosopher #%d: ends eating\n", philosopherIndex);
}

// void putDownChopsticks(int philosopherIndex) {
//     int leftChopstick = philosopherIndex;
//     int rightChopstick = (philosopherIndex + 1) % NUM_PHILOSOPHERS;

//     // Unlock the left chopstick
//     pthread_mutex_unlock(&chopsticks[leftChopstick]);
//     printf("Philosopher #%d: puts down left chopstick %d\n", philosopherIndex, leftChopstick);

//     // Unlock the right chopstick
//     pthread_mutex_unlock(&chopsticks[rightChopstick]);
//     printf("Philosopher #%d: puts down right chopstick %d\n", philosopherIndex, rightChopstick);
// }

void *philosopherThread(void *pVoid) {
    int philosopherIndex = *((int *)pVoid);

    for (int cycle = 0; cycle < NUM_CYCLES; cycle++) {
        thinking(philosopherIndex);
        pickUpChopsticks(philosopherIndex);
        eating(philosopherIndex);
        // putDownChopsticks(philosopherIndex);
    }

    return NULL;
}

int main() {
    srand(time(NULL));

    pthread_t threads[NUM_PHILOSOPHERS];
    int threadArgs[NUM_PHILOSOPHERS];

    pthread_mutex_init(&globalMutex, NULL);

    pthread_cond_init(&nextPhilosopher, NULL);

    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        threadArgs[i] = i;
        pthread_create(&threads[i], NULL, philosopherThread, &threadArgs[i]);
    }

    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&globalMutex);
    pthread_cond_destroy(&nextPhilosopher);

    return 0;
}
