#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

void sigchld_handler(int signo) {
    pid_t child_pid = wait(NULL);
    printf("%d\n", child_pid);
}

int main() {
    // Set up the SIGCHLD signal handler
    
    signal(SIGCHLD , sigchld_handler);
    pid_t child_pid = fork();


    if (child_pid == 0) { // Child process
            printf("parent - %d\n", getppid());
            printf("child - %d\n", getpid());
        pid_t grand_child_pid = fork();
        if (grand_child_pid == 0){
            //grandchild
            printf("grandchild - %d\n", getpid());
            sleep(2);
            exit(0);
        }else{
            //child
            printf("child sleeping for 1 second\n");
            sleep(1);
            printf("child exiting\n");
            exit(0);
        }
    }else{
        sleep(5);
    }
    return 0;
}
