#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

void sigchld_handler(int signo) {
    int status;
    pid_t child_pid;
 
    while ((child_pid = waitpid(-1, &status, WNOHANG)) > 0) {
        if (WIFEXITED(status)) {
            printf("Child %d exited with status %d\n", child_pid, WEXITSTATUS(status));
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number_of_children>\n", argv[0]);
        return 1;
    }

    int num_children = atoi(argv[1]);

    if (num_children <= 0) {
        fprintf(stderr, "Please provide a positive integer for the number of children.\n");
        return 1;
    }

    // Set up the SIGCHLD signal handler
    struct sigaction sa;
    sa.sa_handler = sigchld_handler;
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;
    sigaction(SIGCHLD, &sa, NULL);

    // Spawn child processes
    for (int i = 0; i < num_children; i++) {
        pid_t child_pid = fork();

        if (child_pid == -1) {
            perror("fork");
            return 1;
        } else if (child_pid == 0) { // Child process
            srand(time(NULL) + i); // Seed random number generator
            int sleep_duration = rand() % 5 + 1; // Sleep for 1 to 5 seconds
            sleep(sleep_duration);
            exit(0);
        }
    }

    // Parent process
    while (1) {
        // Parent continues to run and handle SIGCHLD
        sleep(1); // Sleep to avoid busy-waiting
    }

    return 0;
}

