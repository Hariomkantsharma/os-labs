#include <iostream>
#include <vector>
#include <limits>
#include <algorithm>

struct Process {
    int processId;     // Process ID
    int burstTime;     // Burst Time
    int arrivalTime;   // Arrival Time
};

// Function to find the waiting time for all processes
void findWaitingTime(const std::vector<Process>& processes, std::vector<int>& waitingTimes) {
    int n = processes.size();
    std::vector<int> remainingTimes(n);

    for (int i = 0; i < n; i++) {
        remainingTimes[i] = processes[i].burstTime;
    }

    int completedProcesses = 0, currentTime = 0, minRemainingTime = std::numeric_limits<int>::max();
    int shortestProcessIndex = 0, finishTime;
    bool processFound = false;

    while (completedProcesses != n) {
        for (int j = 0; j < n; j++) {
            if (processes[j].arrivalTime <= currentTime && remainingTimes[j] < minRemainingTime && remainingTimes[j] > 0) {
                minRemainingTime = remainingTimes[j];
                shortestProcessIndex = j;
                processFound = true;
            }
        }

        if (!processFound) {
            currentTime++;
            continue;
        }

        remainingTimes[shortestProcessIndex]--;

        minRemainingTime = remainingTimes[shortestProcessIndex];

        if (minRemainingTime == 0) {
            minRemainingTime = std::numeric_limits<int>::max();
        }

        if (remainingTimes[shortestProcessIndex] == 0) {
            completedProcesses++;
            processFound = false;

            finishTime = currentTime + 1;

            waitingTimes[shortestProcessIndex] = finishTime - processes[shortestProcessIndex].burstTime - processes[shortestProcessIndex].arrivalTime;

            if (waitingTimes[shortestProcessIndex] < 0) {
                waitingTimes[shortestProcessIndex] = 0;
            }
        }

        currentTime++;
    }
}

// Function to calculate turn around time
void findTurnAroundTime(const std::vector<Process>& processes, const std::vector<int>& waitingTimes, std::vector<int>& turnaroundTimes) {
    int n = processes.size();
    for (int i = 0; i < n; i++) {
        turnaroundTimes[i] = processes[i].burstTime + waitingTimes[i];
    }
}

// Function to calculate average time
void findAverageTime(std::vector<Process>& processes) {
    int n = processes.size();
    std::vector<int> waitingTimes(n, 0);
    std::vector<int> turnaroundTimes(n, 0);

    findWaitingTime(processes, waitingTimes);
    findTurnAroundTime(processes, waitingTimes, turnaroundTimes);

    float totalWaitingTime = 0, totalTurnaroundTime = 0;

    std::cout << "Process\tBurst Time\tWaiting Time\tTurnaround Time\n";

    for (int i = 0; i < n; i++) {
        totalWaitingTime += waitingTimes[i];
        totalTurnaroundTime += turnaroundTimes[i];
        std::cout << processes[i].processId << "\t" << processes[i].burstTime << "\t\t" << waitingTimes[i] << "\t\t" << turnaroundTimes[i] << "\n";
    }

    std::cout << "\nAverage Waiting Time = " << totalWaitingTime / n;
    std::cout << "\nAverage Turnaround Time = " << totalTurnaroundTime / n;
}

bool arrivalTimeComparator(const Process& a, const Process& b) {
    return a.arrivalTime < b.arrivalTime;
}

int main() {
    std::vector<Process> processes = {{1, 6, 2}, {2, 2, 5}, {3, 8, 1}, {4, 3, 0}, {5, 4, 4}};
    int n = processes.size();

    std::sort(processes.begin(), processes.end(), arrivalTimeComparator);

    findAverageTime(processes);

    return 0;
}
