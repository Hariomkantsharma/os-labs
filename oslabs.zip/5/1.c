#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<sys/types.h>
#include<unistd.h>
#include<signal.h>
void signal_handler(int sig);


void signal_handler(int sig){
    char ans;
    scanf("%c", &ans);
   if(ans == 'y'){
    exit(0);
   }

}
int main(){
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
 

  while(1){
    sleep(1);

  }
  return 0;
}


