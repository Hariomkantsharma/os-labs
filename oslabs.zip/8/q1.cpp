#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

int main() {
    int shmid;
    int *shared_memory;

    // Create a shared memory segment
    shmid = shmget(IPC_PRIVATE, sizeof(int), 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    // Attach the shared memory segment to the current process
    shared_memory = (int *) shmat(shmid, NULL, 0);
    if (shared_memory == (int *) -1) {
        perror("shmat");
        exit(1);
    }

    // Initialize the shared memory segment to 0
    *shared_memory = 0;

    // Fork the parent process into two child processes A and B
    pid_t pidA = fork();
    if (pidA == 0) {
        for (int i = 0; i < 100000; i++) {
            (*shared_memory)++;
            usleep(1);
        }
        exit(0);
    } else {
        pid_t pidB = fork();
        if (pidB == 0) {
            for (int i = 0; i < 100000; i++) {
                (*shared_memory)--;
                usleep(1);
            }
            exit(0);
        } else {
            waitpid(pidA, NULL, 0);
            waitpid(pidB, NULL, 0);

            printf("Final value of X: %d\n", *shared_memory);

            // Detach the shared memory segment from the current process
            shmdt(shared_memory);
            
            // Remove the shared
            shmctl(shmid, IPC_RMID, NULL);
        }
    }
    return 0;
}