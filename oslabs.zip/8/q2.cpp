#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>

int main() {
    int shmid;
    int *shared_memory;
    key_t key = ftok(".", 'shared_memory');
    
    // Create a shared memory segment
    shmid = shmget(key, sizeof(int), IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }

    // Attach the shared memory segment to the current process
    shared_memory = (int *)shmat(shmid, NULL, 0);

    // Initialize the shared memory segment to 0
    *shared_memory = 0;

    // Create and initialize a semaphore
    int semid = semget(key, 1, IPC_CREAT | 0666);
    if (semid == -1) {
        perror("semget");
        exit(1);
    }
    
    // Initialize the semaphore with a value of 1
    semctl(semid, 0, SETVAL, 1);

    // Fork child process A
    pid_t pidA = fork();

    if (pidA == 0) {  
        struct sembuf sem_wait = {0, -1, 0};
        struct sembuf sem_signal = {0, 1, 0};

        for (int i = 0; i < 100000; i++) {
            semop(semid, &sem_wait, 1);  // Wait
            (*shared_memory)++;
            semop(semid, &sem_signal, 1);  // Signal
            usleep(1);
        }
        exit(0);
    }

    // Fork child process B
    pid_t pidB = fork();

    if (pidB == 0) {
        struct sembuf sem_wait = {0, -1, 0};
        struct sembuf sem_signal = {0, 1, 0};

        for (int i = 0; i < 100000; i++) {
            semop(semid, &sem_wait, 1);  // Wait
            (*shared_memory)--;
            semop(semid, &sem_signal, 1);  // Signal
            usleep(1);
        }
        exit(0);
    }

    // Wait for both child processes to finish
    wait(NULL);
    wait(NULL);

    printf("Final value of X: %d\n", *shared_memory);

    // Detach and remove shared memory
    shmdt(shared_memory);
    shmctl(shmid, IPC_RMID, NULL);

    // Remove the semaphore
    semctl(semid, 0, IPC_RMID);

    return 0;
}
