#include <iostream>
using namespace std;
int main()
{
int a = 1;
while(a) { // the while condition will always be met as will always return true.
cout << "Infinite loop\n" << endl;
}
}
