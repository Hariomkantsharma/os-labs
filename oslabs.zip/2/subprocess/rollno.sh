#!/bin/bash

rollno="$1"
echo your roll no is $rollno
for((i=1; i<=100000000; i++)); do
	echo $i
done
