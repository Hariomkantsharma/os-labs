#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h> // Include for wait function

int main() {
    int num_processes = 5;

    for (int i = 0; i < num_processes; i++) {
        pid_t child_pid = fork();

        if (child_pid == -1) {
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (child_pid == 0) {
            // Child process
            printf("Child process %d (PID: %d) created.\n", i + 1, getpid());
            exit(EXIT_SUCCESS);
        }
    }

    // Parent process
    for (int i = 0; i < num_processes; i++) {
        wait(NULL); // Wait for child processes to complete
    }

    printf("All child processes have completed.\n");

    return 0;
}

