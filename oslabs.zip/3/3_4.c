#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    char *filename = argv[1];
    FILE *file = fopen(filename, "w");

    if (!file) {
        perror("Error opening file");
        return 1;
    }

    pid_t pid = fork();

    if (pid == -1) {
        perror("Error forking");
        fclose(file);
        return 1;
    } else if (pid == 0) {
        // Child process
        const char *childMsg = "hello world! I am the child\n";
        fprintf(file, "%s", childMsg);
        exit(0);
    } else {
        // Parent process
        const char *parentMsg = "hello world! I am the parent\n";
        fprintf(file, "%s", parentMsg);
        fclose(file);

        int status;
        waitpid(pid, &status, 0);

        if (WIFEXITED(status)) {
            printf("Child process exited with status: %d\n", WEXITSTATUS(status));
        } else {
            printf("Child process exited abnormally\n");
        }
    }

    return 0;
}

