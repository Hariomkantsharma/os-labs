#include <stdio.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
 
// int main(){
int main(int argc , char *argv[]){
    //  if (argc != 2) {
    //     fprintf(stderr, " Error %s \n", argv[0]);
    //     return 1;
    // }

    char *filename = argv[1];
    FILE *file =fopen(filename, "w");

    pid_t pid =fork();
    if(pid < 0){
        fprintf(stderr, "Fork failed\n");
        return 1;
    }
    if(pid == 0){
        char *childmsg = "Hell0 i am child";
        fprintf(file, "%s", childmsg);
        fclose(file);
        // printf("CHild created %d\n", getpid());
        // printf("parent %d n", getppid());
         exit(0);
    }
    else{
         int status;
         waitpid(pid, &status , 0 );
         if(WIFEXITED(status)){
            printf("Child exited with status %d", status);

         }
         wait(NULL);
        printf("parent id is %d\n", getpid());
         printf("Chid id is %d\n", pid);
    }
    return 0;
}