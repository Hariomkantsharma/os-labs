#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    const char *filename = argv[1];

    pid_t pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Fork failed.\n");
        return 1;
    } else if (pid == 0) {
        // Child process
        close(0); // Close stdout
        int fd = open(filename, O_RDONLY); // Open the file for reading
        if (fd == -1) {
            perror("Error opening file");
            return 1;
        }

        execlp("./mycat", "mycat", NULL);
        perror("execlp"); // If exec fails
        return 1;
    } else {
        // Parent process
        wait(NULL); // Wait for the child process to complete
        printf("Parent : Child process has completed\n");
    }

    return 0;
}
