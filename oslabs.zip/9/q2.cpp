#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_map>
using namespace std;

vector<int> index;
vector<int> values;
unordered_map<int, int> usageOrder; // To store the usage order of keys

int main() {
    int t;
    cin >> t;

    while (t--) {
        int cap = 0;
        int queries = 0;
        cin >> cap >> queries;

        index.clear();
        values.clear();
        usageOrder.clear();

        string s;
        cin >> s;

        for (int i = 0; i < s.length(); ++i) {
            if (s[i] == 'S') {
                int key = s[i + 1] - '0';
                int value = s[i + 2] - '0';

                auto it = find(index.begin(), index.end(), key);

                if (it != index.end()) {
                    // Update the value and update usageOrder
                    values[distance(index.begin(), it)] = value;
                    usageOrder[key] = i;
                } else {
                    if (index.size() < cap) {
                        // Add a new key-value pair
                        index.push_back(key);
                        values.push_back(value);
                        usageOrder[key] = i;
                    } else {
                        // Find the MRU key and replace it
                        int mruKey = -1;
                        int maxUsage = -1;

                        for (const auto& entry : usageOrder) {
                            if (entry.second > maxUsage) {
                                maxUsage = entry.second;
                                mruKey = entry.first;
                            }
                        }

                        auto mruIt = find(index.begin(), index.end(), mruKey);
                        int mruIndex = distance(index.begin(), mruIt);

                        // Replace MRU key with the new key and update value and usageOrder
                        index[mruIndex] = key;
                        values[mruIndex] = value;
                        usageOrder[key] = i;
                    }
                }

                i += 2; // Skip the processed characters
            } else {
                int query = s[i + 1] - '0';
                auto it = find(index.begin(), index.end(), query);

                if (it != index.end()) {
                    cout << *(values.begin() + distance(index.begin(), it)) << endl;
                    usageOrder[query] = i;
                } else {
                    cout << "Not Found\n";
                }

                ++i; // Skip the processed character
            }
        }
    }

    return 0;
}

// 1
// 2
// 4
// S12S23S34G2
// Not Found