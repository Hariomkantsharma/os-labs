
#include <bits/stdc++.h>
using namespace std;

vector<vector<int>> allocation;
vector<vector<int>> need;
vector<vector<int>> ans;

bool is_safe(int process, vector<int>& available) {
    for (int i=0; i<3; i++) {
        if (need[process][i] > available[i]) {
            return false;
        }
    }
    return true;
}

void find_safe_sequence(int processes, vector<int> sequence, vector<bool> finished, vector<int> available) {
    if (sequence.size()==processes) {
        ans.push_back(sequence);
        return;
    }
    for (int i=0; i<processes; i++) {
        if (!finished[i] && is_safe(i, available)) {
            for (int j=0; j<3; j++) available[j] += allocation[i][j];
            sequence.push_back(i);
            finished[i] = true;
            find_safe_sequence(processes, sequence, finished, available);
            finished[i]=false;
            sequence.pop_back();
            for (int j=0; j<3; j++) available[j] -= allocation[i][j];
        }
    }
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        vector<vector<int>> maximum(n, vector<int>(3));
        vector<int> available(3);
        vector<int> sequence;
        allocation.resize(n,vector<int>(3));
        need.resize(n,vector<int>(3));
        for (int i=0; i<3; i++){
            cin>>available[i];
        }
        for (int i=0; i<n; i++) {
            for (int j=0; j<3; j++) {
                cin>>allocation[i][j];
            }
            for (int j=0; j<3; j++) {
                cin>>maximum[i][j];
            }
        }
       
        for (int i=0; i<n; i++) {
            for (int j=0; j<3; j++) {
                need[i][j] = maximum[i][j] - allocation[i][j];
            }
        }
        vector<bool> finished(n, false);
        find_safe_sequence(n, sequence, finished, available);
        if (ans.size()==0) cout<<"No Safe Sequence\n";
        else{
            // cout<<ans.size()<<'\n';
            for (int i=0; i<ans.size(); i++){
                for (int j=0; j<n; j++) cout<<ans[i][j]<<' ';
                cout<<'\n';
            }
        }
    }
    return 0;
}
