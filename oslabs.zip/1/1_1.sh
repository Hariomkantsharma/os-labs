sd=0
rev=0
n=$1

if [ -z "$1" ];
then
echo "Error - no input provided"
exit 64
fi

while [ $n -gt 0 ]
do
    sd=$(( $n % 10 ))
    rev=$(( $rev * 10 + $sd ))
    n=$(( $n / 10 ))
done

echo "Reverse number of entered digit is $rev"
