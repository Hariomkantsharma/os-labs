#!/bin/bash

echo give your name

read name

echo your name is $name
