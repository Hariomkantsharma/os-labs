#!/bin/bash

x=$1
y=$2

if [ $x -gt $y ];
then

while [ $x -gt $y ];
do
	echo $x
	echo " "
	x=$(( $x-1 ))
done

else

while [ $x -lt $y ];
do 
        echo $x
        echo " "
        x=$(( $x+1 ))
done

fi

echo $y
