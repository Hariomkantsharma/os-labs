#!/bin/bash

x="$1"
y="$2"
z="$3"

num=1

for f in "$dir/"; do
	if [ -f  "$f" ] && [[ $(basename "$f") == *"$y"* ]]; then
		ext="txt"
		nn="${z}_${num}.${ext}"
		mv "$f" "$x/$nn"
		num=$(( $num+1 ))
	fi
done
