#!/bin/bash

filename="/home/student/2101CS01/num.txt"

for n in $(cat $filename);

do 

	echo $n

done
