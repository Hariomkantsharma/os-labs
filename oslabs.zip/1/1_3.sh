#!/bin/bash

x=$1
y=$2
numl=0

for n in $(cat $x);

do 

	numl=$(( $numl+1 ))

done

echo $numl

if [ $numl -lt  $y ];
then

echo "deleting file..."
rm $x

fi

