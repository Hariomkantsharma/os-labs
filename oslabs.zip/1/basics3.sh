#!/bin/bash

echo enter a number

read x

if [ $((x%2)) == 0 ]; then
	echo "even"
else 
	echo "odd"
fi

x=2
y=5

n=$(($x+$y))

echo $n

echo enter an option
echo enter 1 for date
echo enter 2 for display contents
echo enter 3 for display path

read m

case $m in 

	1)
	echo $(date)
	;;

	2)
	ls -ltr
	;;

	3)
	pwd
	;;
esac
