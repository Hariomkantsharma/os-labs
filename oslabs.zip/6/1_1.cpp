#include <stdio.h>

// Function to find the waiting time for all processes
void findWaitingTime(int processes[], int n, int bt[], int wt[], int at[]) {
  wt[0] = 0; // Waiting time for first process is 0
  // Calculating waiting time for all other processes
  for (int i = 1; i < n; i++) {
    wt[i] = wt[i - 1] + bt[i - 1];
  }
}

// Function to find the turn around time for all processes
void findTurnAroundTime(int processes[], int n, int bt[], int wt[], int tat[]) {
  // Calculating turnaround time for all processes
  for (int i = 0; i < n; i++) {
    tat[i] = wt[i] + bt[i];
  }
}

// Function to find the average waiting time and average turn around time
void findavgTime(int processes[], int n, int bt[], int at[]) {
  int wt[n], tat[n];

  // Function to find waiting time for all processes
  findWaitingTime(processes, n, bt, wt, at);

  // Function to find turn around time for all processes
  findTurnAroundTime(processes, n, bt, wt, tat);

  // Calculate total waiting time and total turn around time
  int total_wt = 0, total_tat = 0;
  for (int i = 0; i < n; i++) {
    total_wt += wt[i];
    total_tat += tat[i];
  }

  // Calculate average waiting time and average turn around time
  float avg_wt = (float)total_wt / n;
  float avg_tat = (float)total_tat / n;

  // Print average waiting time and average turn around time
  printf("Average waiting time = %f\n", avg_wt);
  printf("Average turn around time = %f\n", avg_tat);
}

int main() {
  int processes[] = {1, 2, 3, 4};
  int burst_time[] = {5, 3, 8, 6};
  int arrival_time[] = {0, 1, 2, 3};
  int n = sizeof(processes) / sizeof(processes[0]);

  // Function to find average waiting time and average turn around time
  findavgTime(processes, n, burst_time, arrival_time);

  return 0;
}
