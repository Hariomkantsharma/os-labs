#include <stdio.h>

// Structure to store process information
typedef struct {
  int pid; // Process ID
  int bt; // Burst time
  int at; // Arrival time
} Process;

// Function to sort processes according to their burst time
void sortByBurstTime(Process processes[], int n) {
  for (int i = 0; i < n - 1; i++) {
    for (int j = i + 1; j < n; j++) {
      if (processes[i].bt > processes[j].bt) {
        Process temp = processes[i];
        processes[i] = processes[j];
        processes[j] = temp;
      }
    }
  }
}

// Function to find the waiting time for all processes
void findWaitingTime(Process processes[], int n, int wt[]) {
  wt[0] = 0; // Waiting time for first process is 0
  // Calculating waiting time for all other processes
  for (int i = 1; i < n; i++) {
    wt[i] = wt[i - 1] + processes[i - 1].bt;
  }
}

// Function to find the turn around time for all processes
void findTurnAroundTime(Process processes[], int n, int wt[], int tat[]) {
  // Calculating turnaround time for all processes
  for (int i = 0; i < n; i++) {
    tat[i] = wt[i] + processes[i].bt;
  }
}

// Function to find the average waiting time and average turn around time
void findavgTime(Process processes[], int n, int tat[], int wt[]) {
  // Calculate total waiting time and total turn around time
  int total_wt = 0, total_tat = 0;
  for (int i = 0; i < n; i++) {
    total_wt += wt[i];
    total_tat += tat[i];
  }

  // Calculate average waiting time and average turn around time
  float avg_wt = (float)total_wt / n;
  float avg_tat = (float)total_tat / n;

  // Print average waiting time and average turn around time
  printf("Average waiting time = %f\n", avg_wt);
  printf("Average turn around time = %f\n", avg_tat);
}

int main() {
  // Process information
  Process processes[] = {{1, 6, 2}, {2, 2, 5}, {3, 8, 1}, {4, 3, 0}, {5, 4, 4}};
  int n = sizeof(processes) / sizeof(processes[0]);

  // Sort processes according to their burst time
  sortByBurstTime(processes, n);

  // Find waiting time for all processes
  int wt[n];
  findWaitingTime(processes, n, wt);

  // Find turn around time for all processes
  int tat[n];
  findTurnAroundTime(processes, n, wt, tat);

  // Find average waiting time and average turn around time
  findavgTime(processes, n, tat, wt);

  return 0;
}
