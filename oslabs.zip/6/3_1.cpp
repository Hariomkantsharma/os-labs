#include <bits/stdc++.h>

using namespace std;

int main(){
	int n;
	//cout << "enter no of processes:" << endl;
	//cin >> n;
	n = 5;
	vector<vector<int>> p = {{1, 2, 6, 0}, {2, 5, 2, 0}, {3, 1, 8, 0}, {4, 0 , 3, 0}, {5, 4, 4, 0}};
	vector<int> ans;
	vector<int> wt;
	vector<int> tn;
	
	//for(int i = 0 ; i < n ; i++){
	//	cout << "enter pid, arrival time , burst time" << endl;
	//	vector<int> temp(4);
	//	cin >> temp[0]; //pid
	//	cin >> temp[1]; //arrival
	//	cin >> temp[2]; //burst
	//	temp[3] = 0 ; //exec
	//	p.push_back(temp);
	//}
	
	
        sort(p.begin(), p.end(), [](vector <int> a, vector<int> b){return a[1] < b[1];}); // sort by arrival times
	
	int curtime = 0;
	int prevminind = 0;
	int laststartime = 0;
	while(ans.size() != n){
        	int minind = -1;
        	int min = 99999;
        	for(int i = 0 ; i < n ; i++){
        		if(p[i][1] <= curtime && !p[i][3]){
        			if(p[i][2] <= min){
        				min = p[i][2];
        				minind = i;
				}
        		
			}
        		
        	}
        	
        	if(!curtime){
        		prevminind = minind;
        		p[minind][2]--;
        		curtime+=1;
        		continue;
        	}
		
			
        	if(minind == -1){
        		curtime+=1;
        		laststartime=0;
        		continue;
        	}
        	
        	curtime+=1;
        	 
		if(prevminind == minind){
                     laststartime+=1;
                     p[minind][2]--;
		}else{
                     laststartime=0;
		}
		
		if(p[minind][2] == 0){
			ans.push_back(minind);
			p[minind][3] = 1;
			ans.push_back(minind);
			wt.push_back(curtime - laststartime - p[minind][1]); 
        		tn.push_back(curtime-p[minind][1]); // curtime-arrival = wtime
		}
		
		cout << curtime << endl;
	}
	
	//for(int i = 0 ; i < n ; i++){
	//	cout << ans[i] << " " << wt[i] << " " << tn[i] << endl;
	//}
	double avgwait = accumulate(wt.begin(), wt.end(), 0);
	double avgtn = accumulate(tn.begin(), tn.end(), 0);
	avgwait/=n;
	avgtn/=n;
	cout << "Average Waiting Time: " << avgwait << "Average Waiting Time: " << avgtn << endl;
	return 0;
}
