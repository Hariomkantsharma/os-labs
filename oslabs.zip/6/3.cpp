#include <stdio.h>
#include <stdlib.h>

struct Process {
    int name;
    int arrival_time;
    int burst_time;
    int completion_time;
    int waiting_time;
    int turnaround_time;
    int remaining_time;
    int executed_time;
};

void swap(struct Process *xp, struct Process *yp) {
    struct Process temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void sort_by_arrival_time(struct Process processes[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (processes[j].arrival_time > processes[j + 1].arrival_time) {
                swap(&processes[j], &processes[j + 1]);
            }
        }
    }
}

int main() {
    int n = 5; // Number of processes
    struct Process processes[] = {
        {1, 2, 6, 0, 0, 0, 6, 0},
        {2, 5, 2, 0, 0, 0, 2, 0},
        {3, 1, 8, 0, 0, 0, 8, 0},
        {4, 0, 3, 0, 0, 0, 3, 0},
        {5, 4, 4, 0, 0, 0, 4, 0}
    };

    int total_waiting_time = 0;
    int total_turnaround_time = 0;
    int completed = 0;
    int current_time = 0;

    while (completed < n) {
        int min_remaining_time = 9999;
        int min_index = -1;

        for (int i = 0; i < n; i++) {
            if (processes[i].arrival_time <= current_time && processes[i].remaining_time < min_remaining_time && processes[i].remaining_time > 0) {
                min_remaining_time = processes[i].remaining_time;
                min_index = i;
            }
        }

        if (min_index == -1) {
            current_time++;
        } else {
            processes[min_index].remaining_time--;
            current_time++;
            processes[min_index].executed_time++;

            if (processes[min_index].executed_time == processes[min_index].burst_time) {
                completed++;
                processes[min_index].completion_time = current_time;
                processes[min_index].turnaround_time = processes[min_index].completion_time - processes[min_index].arrival_time;
                processes[min_index].waiting_time = processes[min_index].turnaround_time - processes[min_index].burst_time;
                total_waiting_time += processes[min_index].waiting_time;
                total_turnaround_time += processes[min_index].turnaround_time;
            }
        }
    }

    double average_waiting_time = (double)total_waiting_time / n;
    double average_turnaround_time = (double)total_turnaround_time / n;

    printf("Average waiting Time: %.2lf\n", average_waiting_time);
    printf("Average Turnaround Time: %.2lf\n", average_turnaround_time);

    return 0;
}

