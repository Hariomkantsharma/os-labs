#include <iostream>
#include <vector>
#include <windows.h>

using namespace std;

int main()
{
    HANDLE hMapFile = OpenFileMapping(FILE_MAP_ALL_ACCESS,FALSE,"Local\\ActivityMonitor");

    if (hMapFile == NULL) {
        cerr << "Not able to create the mapping object: " << GetLastError() << endl;
        return 1;
    }

    unsigned long long* pBuf = (unsigned long long*)MapViewOfFile(hMapFile,FILE_MAP_ALL_ACCESS,0,0,0);

    if (pBuf == NULL) {
        cerr << "Not able to map the file: " << GetLastError() << endl;
        CloseHandle(hMapFile);
        return 1;
    }

    int n = GetFileSize(hMapFile, NULL) / sizeof(unsigned long long);
    cout << "Catalan Numbers: ";
    for (int i = 0; i < n; ++i) {
        if (!pBuf[i]) {
            continue;
        }
        cout << pBuf[i] << " ";
    }
    cout << endl;

    UnmapViewOfFile(pBuf);
    CloseHandle(hMapFile);

    return 0;
}
