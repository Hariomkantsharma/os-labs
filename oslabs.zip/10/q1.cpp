#include <iostream>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <algorithm>

using namespace std;

// Function to simulate FIFO page replacement algorithm
/**
 * @brief The function to do the FIFO page replacement algorithm.
 * First we are defining the pageFaults variable to count the number of page faults.
 * Then we are creating a unordered_set to store the pages in the frame.
 * Then we are creating a queue to store the pages in the order they are coming.
 * Then we are iterating through the pages and checking if the page is present in the frame or not.
 * If the page is not present in the frame then we are incrementing the pageFaults variable.
 * Then we are checking if the frame is full or not.
 * If the frame is full then we are removing the first page from the queue and the frame.
 * Then we are inserting the page in the frame and the queue.
 * Finally we are returning the pageFaults variable.
 * 
 * @param pages 
 * @param capacity 
 * @return int 
 */
int fifoPageReplacement(vector<int>& pages, int capacity) {
    int faults = 0;
    unordered_set<int> frame;
    queue<int> fifo;

    for (int page : pages) {
        if (frame.find(page) == frame.end()) {
            faults++;

            if (frame.size() == capacity) {
                int val = fifo.front();
                fifo.pop();
                frame.erase(val);
            }

            frame.insert(page);
            fifo.push(page);
        }
    }

    return faults;
}

// Function to simulate LRU page replacement algorithm
/**
 * @brief Function to simulate LRU page replacement algorithm.
 * First we are defining the pageFaults variable to count the number of page faults.
 * Then we are creating a vector to store the pages in the frame.
 * Then we are creating a unordered_map to store the indexes of the pages in the frame.
 * Then we are iterating through the pages and checking if the page is present in the frame or not.
 * If the page is not present in the frame then we are incrementing the pageFaults variable.
 * Then we are checking if the frame is full or not.
 * If the frame is full then we are finding the page which is least recently used.
 * Then we are removing the page from the frame and the unordered_map.
 * Then we are inserting the page in the frame and the unordered_map.
 * Finally we are returning the pageFaults variable.
 * 
 * @param pages 
 * @param capacity 
 * @return int 
 */
int lruPageReplacement(vector<int>& pages, int capacity) {
    int pageFaults = 0;
    vector<int> frame;
    unordered_map<int, int> indexes;

    for (int i = 0; i < pages.size(); ++i) {
        if (indexes.find(pages[i]) == indexes.end()) {
            pageFaults++;

            if (frame.size() == capacity) {
                int minIndex = min_element(frame.begin(), frame.end(), [&](int a, int b) {
                    return indexes[a] < indexes[b];
                }) - frame.begin();
                indexes.erase(frame[minIndex]);
                frame[minIndex] = pages[i];
            } else {
                frame.push_back(pages[i]);
            }

            indexes[pages[i]] = i;
        } else {
            indexes[pages[i]] = i;
        }
    }

    return pageFaults;
}

int main() {
    vector<int> pageReferenceString;
    int n;
    cout << "Please enter the number of pages: ";
    cin >> n;
    cout<< "Please enter the page reference string: ";
    for (int i = 0; i < n; ++i) {
        int page;
        cin >> page;
        pageReferenceString.push_back(page);
    }
    cout << "Page reference string: ";
    for (int page : pageReferenceString) {
        cout << page << " ";
    }
    cout << endl;

    int pageFrames;
    cout << "Please enter the number of page frames: ";
    cin >> pageFrames;

    int fifoFaults = fifoPageReplacement(pageReferenceString, pageFrames);
    int lruFaults = lruPageReplacement(pageReferenceString, pageFrames);

    cout << "FIFO page fault = " << fifoFaults << endl;
    cout << "LRU page fault = " << lruFaults << endl;

    return 0;
}
