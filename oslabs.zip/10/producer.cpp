#include <cstdlib>
#include <iostream>
#include <time.h>
#include <vector>
#include <windows.h>
using namespace std;

int main(int argc, char* argv[])
{
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <catalan_numbers>" << endl;
        return 1;
    }

    int n = atoi(argv[1]);
    // Creating the file mapping object with the attributes
    HANDLE hMapFile = CreateFileMapping(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,n * sizeof(unsigned long long),"Local\\ActivityMonitor");

    if (hMapFile == NULL) {
        cerr << "Not able to create the mapping object: " << GetLastError() << endl;
        return 1;
    }

    unsigned long long* pBuf = (unsigned long long*)MapViewOfFile(hMapFile,FILE_MAP_ALL_ACCESS,0,0,n * sizeof(unsigned long long));

    if (pBuf == NULL) {
        cerr << "Not able to map the file: " << GetLastError() << endl;
        CloseHandle(hMapFile);
        return 1;
    }

    pBuf[0] = 1;
    for (int i = 1; i < n; ++i) {
        pBuf[i] = pBuf[i - 1] * (4 * i - 2) / (i + 1);
    }
    Sleep(10000);
    UnmapViewOfFile(pBuf);
    CloseHandle(hMapFile);

    return 0;
}
